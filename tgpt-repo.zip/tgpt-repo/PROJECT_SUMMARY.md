# tgpt-repo Project Summary

## Overview

This repository provides a **safe, gated, manual-first** agentic Termux → APK pipeline with model plumbing and CI/CD integration. It is designed to prevent token-hungry or destructive automated operations while enabling reproducible Android app builds.

## Key Features

### 1. HMAC-Gated Execution
- **No auto-apply, no auto-deploy**: All script execution requires explicit HMAC token approval
- **Manus safety**: Manus can only run pre-approved scripts listed in `manus_policy.json`
- **Manual control**: You generate HMAC tokens offline and provide them for each execution

### 2. Dual Build Paths

#### Option A: Termux-Native Build
- Build directly on Android device in Termux
- Fast iteration and testing
- Portable, works offline
- Run: `bash scripts/build_termux_p4a.sh`

#### Option B: Docker/CI Cross-Build
- Reproducible builds in CI/GitHub Actions
- JDK 17 and 21 matrix support
- Faster, automatable
- Run: `bash scripts/docker_cross_build.sh`

### 3. Model Integration

#### On-Device (Local, Offline)
- Bundle quantized ggml model in `models/`
- Compile llama.cpp for Android
- Privacy-focused, no API costs

#### Hosted Inference (Cloud)
- Call HTTPS API from app
- Store API key in secure storage
- Powerful models, easier development

### 4. GitHub Actions Workflows

#### `build_apk.yml`
- Builds APK with JDK 17 and 21 matrix
- Caches Buildozer dependencies
- Uploads APK artifacts
- Runs on push to main or manual trigger

#### `manus_safe.yml`
- **Read-only** Manus automation
- Generates analysis reports (dry-run only)
- Creates issues with recommendations
- No automatic code changes or deployments

## Repository Structure

```
tgpt-repo/
├── .github/workflows/
│   ├── build_apk.yml          # CI/CD build pipeline
│   └── manus_safe.yml         # Safe Manus automation (read-only)
├── app/
│   └── main.py                # CLI-first entry (Kivy optional)
├── src/
│   └── tgpt_core.py          # Agent core logic
├── models/                    # On-device models (gitignored)
├── scripts/
│   ├── termux_setup.sh       # Termux environment setup
│   ├── build_termux_p4a.sh   # Termux-native build
│   ├── docker_cross_build.sh # Docker cross-compilation
│   ├── allow_manus.sh        # HMAC gate script
│   └── sign_apk.sh           # APK signing
├── android_build/
│   └── buildozer.spec        # Buildozer configuration
├── ci/
│   ├── Dockerfile            # Docker build environment
│   └── ci_build.sh           # CI build script
├── agent_plan.json           # Allowed automation tasks
├── manus_policy.json         # Manus execution policy
├── requirements.txt          # Python dependencies
├── SECURITY.md               # Security policy and HMAC usage
├── README.md                 # Project documentation
└── LICENSE                   # MIT License
```

## Quick Start

### 1. Clone and Setup

```bash
git clone git@github.com:sir-quantum/tgpt-repo.git
cd tgpt-repo
```

### 2. Termux Setup (on Android device)

```bash
bash scripts/termux_setup.sh
```

### 3. Build APK

**Option A (Termux-native):**
```bash
# Generate HMAC token
export MANUS_HMAC_SECRET="your-secret-key"
HMAC=$(echo -n "scripts/build_termux_p4a.sh" | openssl dgst -sha256 -hmac "$MANUS_HMAC_SECRET" | awk '{print $2}')

# Run gated build
bash scripts/allow_manus.sh scripts/build_termux_p4a.sh $HMAC
```

**Option B (Docker):**
```bash
bash scripts/docker_cross_build.sh
```

### 4. Test CLI

```bash
python app/main.py
```

## Security

### HMAC Token Generation

```bash
# Set secret (keep offline, never commit)
export MANUS_HMAC_SECRET="supersecret"

# Generate HMAC for a script
SCRIPT="scripts/build_termux_p4a.sh"
HMAC=$(echo -n "$SCRIPT" | openssl dgst -sha256 -hmac "$MANUS_HMAC_SECRET" | awk '{print $2}')

echo "HMAC: $HMAC"
```

### Allowed Scripts

Only these scripts can be executed through the HMAC gate (defined in `manus_policy.json`):

- `scripts/termux_setup.sh`
- `scripts/build_termux_p4a.sh`
- `scripts/docker_cross_build.sh`
- `ci/ci_build.sh`

### GitHub Secrets

Store these in GitHub repository secrets:

- `KEYSTORE_PASS` - Release keystore password
- `MODEL_URL` - Hosted model API endpoint (optional)
- `MODEL_KEY` - Hosted model API key (optional)

## Agent Workflow

The agent loop in `src/tgpt_core.py` autonomously:

1. Pulls latest repo changes
2. Runs tests/lint
3. Chooses build option (Termux or Docker)
4. Builds APK
5. Runs smoke tests
6. Uploads artifact and opens PR if model updated

Run with: `python app/main.py` and type `agent` at the prompt.

## CI/CD Pipeline

### Build Matrix

- **JDK 17** and **JDK 21**
- **Python 3.10**
- **Ubuntu latest**

### Artifacts

- APK files uploaded as GitHub Actions artifacts
- Retained for 30 days
- Named: `tgpt-apk-jdk17`, `tgpt-apk-jdk21`

### Caching

- Buildozer dependencies cached
- Speeds up subsequent builds
- Cache key includes buildozer.spec hash

## Development Workflow

### 1. Local Development
- Make changes locally or in Termux
- Test with CLI: `python app/main.py`
- Commit and push to GitHub

### 2. Automated Builds
- Push to `main` triggers CI build
- APK artifacts generated for both JDK versions
- Download from GitHub Actions artifacts

### 3. Manual Builds
- Use HMAC gating for local builds
- Generate token, run through `allow_manus.sh`
- Review build output before deployment

### 4. Release Process
1. Build APK with production configuration
2. Sign with release keystore: `bash scripts/sign_apk.sh <apk_path>`
3. Run smoke tests
4. Create GitHub release
5. Upload signed APK

## Troubleshooting

### Kivy Build Errors

The app is CLI-first. If Kivy fails to build:

1. Set `TGPT_UI=cli` to skip Kivy
2. Build with minimal requirements
3. Test core functionality without UI
4. Add Kivy back after core is stable

### Build Timeout

Increase timeout in `manus_policy.json`:

```json
{
  "max_runtime_seconds": 7200
}
```

### Missing Dependencies

Run setup script again:

```bash
bash scripts/termux_setup.sh
```

## Model Integration Examples

### Hosted Inference

```bash
export MODEL_URL="https://api.example.com/v1/chat"
export MODEL_KEY="your-api-key"
python app/main.py
```

### On-Device Model

1. Download quantized model (e.g., `llama-2-7b-chat.Q4_K_M.gguf`)
2. Place in `models/` directory
3. Update `agent_plan.json`:

```json
{
  "model_integration": {
    "on_device": {
      "enabled": true,
      "model_path": "models/llama-2-7b-chat.Q4_K_M.gguf",
      "backend": "llama.cpp"
    }
  }
}
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes and test locally
4. Submit pull request
5. Wait for CI to pass
6. Request review

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Credits

Built with Manus AI for safe, reproducible, agentic Android app development.

---

**Last Updated**: 2025-01-16
**Version**: 0.1.0
**Status**: Initial Release
