#!/usr/bin/env python3
"""
tgpt agent core (vm2agent_core)
Provides CLI interface and model integration logic
"""

import os
import sys
import subprocess
import json

# Try to import requests for hosted model inference
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    print("[tgpt] Warning: requests not available, hosted inference disabled")


class TGPTAgent:
    """Core agent logic for tgpt"""
    
    def __init__(self):
        self.model_url = os.getenv("MODEL_URL", "")
        self.model_key = os.getenv("MODEL_KEY", "")
        self.use_local = os.getenv("TGPT_LOCAL_MODEL", "false").lower() == "true"
        
    def query_hosted_model(self, prompt):
        """Query hosted model via HTTP API"""
        if not HAS_REQUESTS:
            return "[Error] requests library not available"
            
        if not self.model_url:
            return "[Error] MODEL_URL not set"
            
        try:
            headers = {}
            if self.model_key:
                headers["Authorization"] = f"Bearer {self.model_key}"
                
            response = requests.post(
                self.model_url,
                json={"input": prompt},
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get("text", data.get("output", str(data)))
            else:
                return f"[Error] HTTP {response.status_code}: {response.text}"
                
        except Exception as e:
            return f"[Error] {str(e)}"
            
    def query_local_model(self, prompt):
        """Query local on-device model"""
        # Placeholder for local model integration
        # TODO: Integrate llama.cpp or similar
        return "[Local model not yet implemented]"
        
    def query(self, prompt):
        """Query the appropriate model"""
        if self.use_local:
            return self.query_local_model(prompt)
        else:
            return self.query_hosted_model(prompt)
            
    def run_agent_loop(self):
        """Main agent loop for autonomous operations"""
        print("[tgpt] Agent loop starting...")
        
        # Step A: Pull latest repo changes
        print("[tgpt] Step A: Checking for repo updates...")
        # subprocess.run(["git", "pull"], check=False)
        
        # Step B: Run tests/lint
        print("[tgpt] Step B: Running tests...")
        # subprocess.run(["python3", "-m", "pytest"], check=False)
        
        # Step C: Choose build option
        print("[tgpt] Step C: Determining build environment...")
        is_termux = os.path.exists("/data/data/com.termux")
        build_option = "termux" if is_termux else "docker"
        print(f"[tgpt] Selected build option: {build_option}")
        
        # Step D: Build APK
        print("[tgpt] Step D: Building APK...")
        # if build_option == "termux":
        #     subprocess.run(["bash", "scripts/build_termux_p4a.sh"], check=False)
        # else:
        #     subprocess.run(["bash", "scripts/docker_cross_build.sh"], check=False)
        
        # Step E: Run smoke tests
        print("[tgpt] Step E: Running smoke tests...")
        # subprocess.run(["bash", "scripts/smoke_test.sh"], check=False)
        
        # Step F: Upload artifact
        print("[tgpt] Step F: Uploading artifact...")
        # subprocess.run(["gh", "release", "create", "v0.1", "dist/*.apk"], check=False)
        
        print("[tgpt] Agent loop completed")


def run_cli():
    """Run tgpt in CLI mode"""
    print("=" * 60)
    print("tgpt CLI - Agentic Terminal GPT")
    print("=" * 60)
    print("Commands: 'exit' or 'quit' to exit, 'agent' to run agent loop")
    print()
    
    agent = TGPTAgent()
    
    while True:
        try:
            prompt = input("> ").strip()
            
            if not prompt:
                continue
                
            if prompt.lower() in ("exit", "quit"):
                print("[tgpt] Goodbye!")
                break
                
            if prompt.lower() == "agent":
                agent.run_agent_loop()
                continue
                
            if prompt.lower() == "help":
                print("Available commands:")
                print("  exit, quit - Exit the CLI")
                print("  agent      - Run autonomous agent loop")
                print("  help       - Show this help")
                print("  <text>     - Query the model")
                continue
                
            # Query the model
            print("[tgpt] Thinking...")
            response = agent.query(prompt)
            print(response)
            print()
            
        except KeyboardInterrupt:
            print("\n[tgpt] Interrupted. Type 'exit' to quit.")
        except EOFError:
            print("\n[tgpt] EOF received. Exiting...")
            break


if __name__ == "__main__":
    run_cli()

