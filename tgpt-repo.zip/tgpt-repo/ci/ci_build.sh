#!/bin/bash
# CI build script for tgpt
# Runs inside Docker container or GitHub Actions

set -e

echo "=== tgpt CI Build ==="
echo "Java version: $(java -version 2>&1 | head -n1)"
echo "Python version: $(python3 --version)"
echo

# Navigate to android_build directory
cd android_build

echo "Building APK with Buildozer..."
buildozer -v android debug

echo
echo "=== Build Complete ==="
ls -lh bin/*.apk

