#!/bin/bash
# Build APK using Buildozer in Termux (Option A)

set -e

echo "=== tgpt Termux Build (Option A) ==="
echo

# Check if we're in Termux
if [ ! -d "/data/data/com.termux" ]; then
    echo "Warning: This script is designed for Termux. You may encounter issues."
fi

# Set Java home if available
if [ -d "/data/data/com.termux/files/usr/lib/jvm/java-17-openjdk" ]; then
    export JAVA_HOME=/data/data/com.termux/files/usr/lib/jvm/java-17-openjdk
    echo "Using Java 17: $JAVA_HOME"
elif [ -d "/data/data/com.termux/files/usr/lib/jvm/java-21-openjdk" ]; then
    export JAVA_HOME=/data/data/com.termux/files/usr/lib/jvm/java-21-openjdk
    echo "Using Java 21: $JAVA_HOME"
else
    echo "Warning: Java not found in expected location"
fi

# Navigate to android_build directory
cd "$(dirname "$0")/../android_build"

echo "Building APK with Buildozer..."
echo "This may take 30-60 minutes on first run (downloads SDK/NDK)"
echo

# Run buildozer
buildozer -v android debug

echo
echo "=== Build Complete ==="
echo "APK location: $(pwd)/bin/*.apk"
echo
echo "To install on device:"
echo "  adb install bin/*.apk"
echo

