#!/bin/bash
# Termux bootstrap script for tgpt
# Run this in Termux to set up the build environment

set -e

echo "=== tgpt Termux Setup ==="
echo "This script will install dependencies for building Android APKs in Termux"
echo

# Update and upgrade packages
echo "[1/6] Updating Termux packages..."
pkg update -y
pkg upgrade -y

# Install core dependencies
echo "[2/6] Installing core dependencies..."
pkg install -y git python clang make automake autoconf pkg-config openssl wget unzip zip

# Install Java (try OpenJDK 17, fallback to available version)
echo "[3/6] Installing Java..."
if pkg install -y openjdk-17; then
    echo "OpenJDK 17 installed successfully"
    export JAVA_HOME=/data/data/com.termux/files/usr/lib/jvm/java-17-openjdk
else
    echo "OpenJDK 17 not available, trying openjdk-21..."
    if pkg install -y openjdk-21; then
        echo "OpenJDK 21 installed successfully"
        export JAVA_HOME=/data/data/com.termux/files/usr/lib/jvm/java-21-openjdk
    else
        echo "Warning: Could not install OpenJDK. You may need to install Java manually."
    fi
fi

# Upgrade pip and install Python build tools
echo "[4/6] Installing Python build tools..."
pip install --upgrade pip
pip install cython==0.29.34 python-for-android buildozer

# Install optional dependencies
echo "[5/6] Installing optional dependencies..."
pip install requests  # For hosted model inference

# Setup storage permissions
echo "[6/6] Setting up storage permissions..."
termux-setup-storage || echo "Warning: Could not setup storage (may need manual permission grant)"

echo
echo "=== Setup Complete ==="
echo "Java Home: $JAVA_HOME"
echo "Python version: $(python --version)"
echo "Buildozer version: $(buildozer --version 2>&1 | head -n1)"
echo
echo "Next steps:"
echo "  1. Run: bash scripts/build_termux_p4a.sh"
echo "  2. Or run: python app/main.py (for CLI testing)"
echo

