#!/usr/bin/env bash
# Manus gate script - only runs approved scripts with HMAC verification
set -euo pipefail

POLICY_FILE=manus_policy.json
SCRIPT_TO_RUN="${1:-}"
HMAC_PROVIDED="${2:-}"

if [ -z "$SCRIPT_TO_RUN" ] || [ -z "$HMAC_PROVIDED" ]; then
    echo "ERROR: Usage: $0 <script_path> <hmac_token>" >&2
    echo "Example: $0 scripts/build_termux_p4a.sh <hmac>" >&2
    exit 1
fi

# Check if policy file exists
if [ ! -f "$POLICY_FILE" ]; then
    echo "ERROR: manus_policy.json not found" >&2
    exit 2
fi

# Check if script is in allowed list
if ! jq -e --arg s "$SCRIPT_TO_RUN" '.allowed_scripts[] | select(. == $s)' "$POLICY_FILE" >/dev/null; then
    echo "ERROR: script '$SCRIPT_TO_RUN' not allowed by manus_policy.json" >&2
    echo "Allowed scripts:" >&2
    jq -r '.allowed_scripts[]' "$POLICY_FILE" >&2
    exit 2
fi

# Verify HMAC (in production, compare against computed HMAC using secret)
# For now, we just check it's not empty (you should implement proper HMAC verification)
if [ -z "$HMAC_PROVIDED" ]; then
    echo "ERROR: HMAC token required but not provided" >&2
    exit 3
fi

# Get timeout from policy
TIMEOUT=$(jq -r '.max_runtime_seconds' "$POLICY_FILE")

echo "=== Manus Approved Execution ==="
echo "Script: $SCRIPT_TO_RUN"
echo "Timeout: ${TIMEOUT}s"
echo "HMAC: ${HMAC_PROVIDED:0:16}..."
echo

# Make script executable if not already
chmod +x "$SCRIPT_TO_RUN"

# Run with timeout
timeout --preserve-status "${TIMEOUT}s" bash "$SCRIPT_TO_RUN"

echo
echo "=== Execution Complete ==="

