#!/usr/bin/env bash
# Sign APK for release
set -euo pipefail

APK_PATH="${1:-}"
KEYSTORE_PATH="${2:-tgpt-release.keystore}"
KEYPASS="${3:-${KEYSTORE_PASS:-}}"
ALIAS="${4:-tgpt-key}"

if [ -z "$APK_PATH" ]; then
    echo "ERROR: Usage: $0 <apk_path> [keystore_path] [keypass] [alias]" >&2
    exit 1
fi

if [ ! -f "$APK_PATH" ]; then
    echo "ERROR: APK file not found: $APK_PATH" >&2
    exit 1
fi

if [ ! -f "$KEYSTORE_PATH" ]; then
    echo "ERROR: Keystore not found: $KEYSTORE_PATH" >&2
    echo "Create one with: keytool -genkey -v -keystore $KEYSTORE_PATH -alias $ALIAS -keyalg RSA -keysize 2048 -validity 10000" >&2
    exit 1
fi

if [ -z "$KEYPASS" ]; then
    echo "ERROR: Keystore password not provided (use KEYSTORE_PASS env var or pass as argument)" >&2
    exit 1
fi

# Check if apksigner is available
if ! command -v apksigner &> /dev/null; then
    echo "ERROR: apksigner not found in PATH" >&2
    echo "Install Android SDK build-tools and add to PATH" >&2
    exit 1
fi

OUTPUT_APK="${APK_PATH%.apk}-signed.apk"

echo "=== Signing APK ==="
echo "Input: $APK_PATH"
echo "Keystore: $KEYSTORE_PATH"
echo "Alias: $ALIAS"
echo "Output: $OUTPUT_APK"
echo

apksigner sign \
    --ks "$KEYSTORE_PATH" \
    --ks-pass "pass:$KEYPASS" \
    --key-pass "pass:$KEYPASS" \
    --out "$OUTPUT_APK" \
    "$APK_PATH"

echo
echo "=== Verifying signature ==="
apksigner verify "$OUTPUT_APK"

echo
echo "=== Signing Complete ==="
echo "Signed APK: $OUTPUT_APK"

