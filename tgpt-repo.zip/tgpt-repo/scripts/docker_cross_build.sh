#!/bin/bash
# Build APK using Docker cross-compilation (Option B)

set -e

echo "=== tgpt Docker Cross-Build (Option B) ==="
echo

# Check if Docker is available
if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker is not installed or not in PATH"
    echo "Please install Docker: https://docs.docker.com/get-docker/"
    exit 1
fi

# Navigate to repo root
cd "$(dirname "$0")/.."

echo "Building Docker image..."
docker build -t tgpt-builder -f ci/Dockerfile .

echo
echo "Running build in Docker container..."
docker run --rm \
    -v "$(pwd)":/work \
    -w /work \
    tgpt-builder \
    bash ci/ci_build.sh

echo
echo "=== Build Complete ==="
echo "APK location: $(pwd)/android_build/bin/*.apk"
echo

