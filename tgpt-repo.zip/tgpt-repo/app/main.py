#!/usr/bin/env python3
"""
tgpt main entry point (vm1kivy_main)
Supports both Kivy UI and CLI mode for flexibility during development
"""

import os
import sys

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

def main():
    """Main entry point with UI mode selection"""
    ui_mode = os.getenv("TGPT_UI", "cli").lower()
    
    if ui_mode == "kivy":
        try:
            from kivy_app import run_kivy
            print("[tgpt] Starting Kivy UI...")
            run_kivy()
        except ImportError as e:
            print(f"[tgpt] Kivy not available: {e}")
            print("[tgpt] Falling back to CLI mode...")
            from tgpt_core import run_cli
            run_cli()
    else:
        print("[tgpt] Starting CLI mode...")
        from tgpt_core import run_cli
        run_cli()

if __name__ == "__main__":
    main()

