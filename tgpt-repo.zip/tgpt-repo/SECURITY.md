# Security Policy

## Manus HMAC Gating System

This repository uses an HMAC-based gating system to control automated script execution. This prevents unauthorized or accidental execution of build scripts.

### Generating HMAC Tokens

To allow Manus or any automated system to run a script, you must generate an HMAC token:

```bash
# Set your secret (keep this offline and never commit it)
export MANUS_HMAC_SECRET="your-secret-key-here"

# Generate HMAC for a specific script
SCRIPT="scripts/build_termux_p4a.sh"
HMAC=$(echo -n "$SCRIPT" | openssl dgst -sha256 -hmac "$MANUS_HMAC_SECRET" | awk '{print $2}')

echo "HMAC for $SCRIPT: $HMAC"
```

### Running Gated Scripts

Once you have the HMAC token, you can run the script through the gate:

```bash
bash scripts/allow_manus.sh scripts/build_termux_p4a.sh <HMAC_TOKEN>
```

### Allowed Scripts

Only scripts listed in `manus_policy.json` can be executed through the gate:

- `scripts/termux_setup.sh` - Termux environment setup
- `scripts/build_termux_p4a.sh` - Termux-native APK build
- `scripts/docker_cross_build.sh` - Docker cross-compilation build
- `ci/ci_build.sh` - CI build script

### Security Best Practices

1. **Never commit** `MANUS_HMAC_SECRET` to the repository
2. **Store secrets** in GitHub Secrets for CI/CD workflows
3. **Rotate HMAC secrets** periodically
4. **Review** `manus_policy.json` before adding new allowed scripts
5. **Audit** all script executions through the gate
6. **Use read-only** Manus workflows (no auto-apply, no auto-deploy)

### GitHub Actions Security

All GitHub Actions workflows in this repository follow these principles:

- **Read-only by default**: No automatic code changes or deployments
- **Manual approval required**: All deployments require explicit human approval
- **Minimal permissions**: Workflows use least-privilege access
- **Secret management**: Sensitive data stored in GitHub Secrets only
- **Artifact retention**: Build artifacts retained for limited time

### Reporting Security Issues

If you discover a security vulnerability, please email the repository owner directly. Do not open a public issue.

## Keystore Management

For APK signing:

1. Generate a release keystore locally (never commit to repo)
2. Store keystore password in GitHub Secrets as `KEYSTORE_PASS`
3. Upload keystore to secure storage (not in repo)
4. Reference keystore path in signing scripts

```bash
# Generate release keystore (one-time setup)
keytool -genkey -v \
  -keystore tgpt-release.keystore \
  -alias tgpt-key \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

## Dependencies

- Regularly update dependencies in `requirements.txt`
- Review security advisories for Python packages
- Use `pip-audit` or similar tools to scan for vulnerabilities
- Pin critical dependency versions

## License

See [LICENSE](LICENSE) file for details.

